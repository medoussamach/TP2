package AtelierPOO;
/*class Point {
private char id ;
private double abs ;

// identifiant du Point
// abscisse du Point
public Point (char c, double x) { // constructeur
id = c ;
abs = x ;
}
public void affiche ()
{System.out.println("Point identifié par "+id+" d'abscisse "+abs);}
public void translate (double dx)
{ abs += dx ; }
}

public class AtelierPOO {

	public static void main(String[] args) {
		
		Point a = new Point ('A', 2.5) ;
		a.affiche() ;
		a.translate(2.5);
		a.affiche();
		Point b = new Point ('B', 5.25) ;
		b.affiche() ;
		b.translate(2.25) ;
		b.affiche() ;

	}

}*/
public class AtelierPOO
{
	class Point {
		private String id ;
		private double abs ;
		private double ord ;
		
	class point1 {
		private String id ;
	}
	class point2 {
		private String id ;
		private double abs ;
	}

		// identifiant du Point
		// abscisse du Point
		public Point (String c, double x , double y) { // constructeur
		id = c ;
		abs = x ;
		ord = y ;
		}
		public Point (String c) {
			id = c ;
		}
		public Point (String c, double x) {
			id = c ;
			abs = x ;
		}
		public Point (double x, double y) {
			ord = y ;
			abs = x ;
		}
		public Point () {
			ord=0;
			abs=0;
			id=" ";
		}
		
		public void Affiche() {
			System.out.println(id+"("+abs+","+ord+")");
		}
		public void TranslHoriz (double dx)
		{ abs += dx ; }
		
	public void TranslVert (double dx)
	{ ord += dx ; }
	
	public void Translation (double dx , double dy)
	{ abs += dx ;
	ord += dy ;
	}
	public boolean Coincide(Point p) {
		if (this.abs == p.abs && this.ord == p.ord )
			return true;
	}
	public String getNom() {
		return this.id;
	}
	public double getAbscisse() {
		return this.abs;
	}
	public double getOrdonné() {
		return this.ord;
	}
	public String setNom(String ch) {
		this.id=ch;
	}
	public double setAbscisse(int a) {
		this.abs=a;
	}
	public double setOrdonnée(int a) {
		this.ord=a;
	}
public static void main (String [] args)
{
Point p1;
p1 = new Point (3, 5);
Point p2 = new Point ("a");
Point p3 = new Point ("b", 3,5);
System.out.println("\n ---------------------\n");
System.out.println("les Points créés sont :");

p1.Affiche ();
p2.Affiche ();
p3.Affiche ();

System.out.println("\n ---------------------------\n"); 
if (p1.Coincide(p3) ==true)
	System.out.println("Les 2 Points p1 et p3coïncident");
else
	System.out.println("Les 2 Points necoïncident pas");

System.out.println("\n ---------------------------\n");

System.out.println("translation des Point ");
p1.TranslHoriz (4);
p2.TranslVert (3);
p3.Translation (5,2);
p1.Affiche ();
p2.Affiche ();
p3.Affiche ();

System.out.println("\n ---------------------------\n");
System.out.println("modification des attributs des Points") ;
p1.setNom("SRI21");
p2.setAbscisse(25);
p3.setOrdonnée(50);
p1.Affiche ();
p2.Affiche ();
p3.Affiche ();

System.out.println("\n ---------------------------\n");
System.out.println("utilisation des méthodesget");
String x=p1.getNom();
double y=p1.getAbscisse();
double z=p1.getOrdonné();
System.out.println(" le nom du Point p1 est : " + x);
System.out.println(" son abscisse est : " + y);
System.out.println(" son ordonnée est : " + z);
}
}


