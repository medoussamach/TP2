package AtelierPOO;

import AtelierPOO.AtelierPOO.Point;

	class Point {
		private String id ;
		private double abs ;
		private double ord ;
		

		// identifiant du Point
		// abscisse du Point
		public Point (String c, double x , double y) { // constructeur
		id = c ;
		abs = x ;
		ord = y ;
		}
		public Point (String c) {
			id = c ;
		}
		public Point (String c, double x) {
			id = c ;
			abs = x ;
		}
		public Point (double x, double y) {
			ord = y ;
			abs = x ;
		}
		public Point () {
			ord=0;
			abs=0;
			id=" ";
		}
		
		public void Affiche() {
			System.out.println(id+"("+abs+","+ord+")");
		}
		public void TranslHoriz (double dx)
		{ abs += dx ; }
		
	public void TranslVert (double dx)
	{ ord += dx ; }
	
	public void Translation (double dx , double dy)
	{ abs += dx ;
	ord += dy ;
	}
	public boolean Coincide(Point p) {
		if (this.abs == p.abs && this.ord == p.ord )
			return true;
	}
	public String getNom() {
		return this.id;
	}
	public double getAbscisse() {
		return this.abs;
	}
	public double getOrdonné() {
		return this.ord;
	}
	public String setNom(String ch) {
		this.id=ch;
	}
	public double setAbscisse(int a) {
		this.abs=a;
	}
	public double setOrdonnée(int a) {
		this.ord=a;
	}

