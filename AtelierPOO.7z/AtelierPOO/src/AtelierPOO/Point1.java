package AtelierPOO;

import AtelierPOO.AtelierPOO.Point;

public class Point1 extends Point {

}
